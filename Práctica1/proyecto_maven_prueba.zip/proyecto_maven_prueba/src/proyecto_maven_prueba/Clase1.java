package proyecto_maven_prueba;

import java.util.Random;

public class Clase1 {
    public static void main(String[] args) {
        Random random = new Random();
        int[] pares = new int[3];
        int suma = 0;

        System.out.println("--- Tres números pares aleatorios ---");

        for (int i = 0; i < 3; i++) {
            int parAleatorio = random.nextInt(51) * 2;
            pares[i] = parAleatorio;
            suma += parAleatorio;
            System.out.println("Número " + (i + 1) + ": " + parAleatorio);
        }

        System.out.println("-------------------------------------");
        System.out.println("La suma es: " + suma);
    }
}
