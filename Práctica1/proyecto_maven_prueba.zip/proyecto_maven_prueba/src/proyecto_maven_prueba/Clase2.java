package proyecto_maven_prueba;

import java.util.Random;

public class Clase2 {
    public static void main(String[] args) {
        Random random = new Random();
        StringBuilder letras = new StringBuilder();

        System.out.print("Tres letras al azar: ");
        for (int i = 0; i < 3; i++) {
            char letraAleatoria = (char) (random.nextInt(26) + 'A');
            letras.append(letraAleatoria);
        }

        System.out.println(letras.toString());
    }

}
